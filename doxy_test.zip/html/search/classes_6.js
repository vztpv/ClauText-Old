var searchData=
[
  ['loaddata',['LoadData',['../classwiz_1_1load__data_1_1_load_data.html',1,'wiz::load_data']]]
];
