var searchData=
[
  ['indexerror',['IndexError',['../classwiz_1_1_index_error.html',1,'wiz']]],
  ['infilereserver',['InFIleReserver',['../classwiz_1_1load__data_1_1_in_f_ile_reserver.html',1,'wiz::load_data']]],
  ['iter',['Iter',['../classwiz_1_1_array_1_1_iter.html',1,'wiz::Array']]]
];
