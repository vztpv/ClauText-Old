var searchData=
[
  ['load_5fdata',['load_data',['../namespacewiz_1_1load__data.html',1,'wiz']]],
  ['wiz',['wiz',['../namespacewiz.html',1,'']]]
];
