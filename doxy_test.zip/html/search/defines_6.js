var searchData=
[
  ['or',['OR',['../global_8h.html#a3363ca4d6d3cc0230b2804280591c991',1,'global.h']]],
  ['out',['OUT',['../global_8h.html#aec78e7a9e90a406a56f859ee456e8eae',1,'global.h']]]
];
