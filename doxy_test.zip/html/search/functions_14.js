var searchData=
[
  ['wizobject',['wizObject',['../classwiz_1_1wiz_object.html#a388f40c47e985b9a1380887edb113e95',1,'wiz::wizObject::wizObject()'],['../classwiz_1_1wiz_object.html#a97ca96cf59915d126ab620ffd7d6d238',1,'wiz::wizObject::wizObject(const wizObject &amp;object)']]],
  ['wrapforinfinity',['WrapForInfinity',['../classwiz_1_1_wrap_for_infinity.html#a5704d7340f91b8d1ad4b22d638b5a31b',1,'wiz::WrapForInfinity']]]
];
