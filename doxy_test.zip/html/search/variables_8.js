var searchData=
[
  ['state',['state',['../class_event_info.html#a610a4fbde6184b33b95f3767d7199180',1,'EventInfo']]]
];
