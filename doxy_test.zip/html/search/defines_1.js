var searchData=
[
  ['and',['AND',['../global_8h.html#acd1b97556dfbbac61063a63031d2f91d',1,'global.h']]]
];
