var searchData=
[
  ['usertype_5fidx',['userType_idx',['../class_event_info.html#adf68e89f8aff62ad39ffd8b335c0f3e9',1,'EventInfo']]]
];
