var searchData=
[
  ['nonereserver',['NoneReserver',['../classwiz_1_1load__data_1_1_none_reserver.html',1,'wiz::load_data']]],
  ['normal_5fswap',['NORMAL_SWAP',['../classwiz_1_1_n_o_r_m_a_l___s_w_a_p.html',1,'wiz']]],
  ['not_5fee',['NOT_EE',['../classwiz_1_1_n_o_t___e_e.html',1,'wiz']]],
  ['not_5fee_5fsame_5fvalue',['NOT_EE_SAME_VALUE',['../classwiz_1_1_n_o_t___e_e___s_a_m_e___v_a_l_u_e.html',1,'wiz']]]
];
