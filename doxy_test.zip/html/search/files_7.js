var searchData=
[
  ['stacks_2eh',['stacks.h',['../stacks_8h.html',1,'']]]
];
