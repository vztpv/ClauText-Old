var searchData=
[
  ['begin',['begin',['../classwiz_1_1_deck.html#a4f2e715b0af8b6da9311edcfe0e9b915',1,'wiz::Deck::begin()'],['../classwiz_1_1_array.html#ab54531cde708f1c852f0f3fd91f8fc74',1,'wiz::Array::begin()']]]
];
