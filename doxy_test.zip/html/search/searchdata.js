var indexSectionsWithContent =
{
  0: "_abcdefghilmnopqrstuvw~",
  1: "acdehilnpqrstuw",
  2: "w",
  3: "cdglnqrstw",
  4: "_abcdefghilmnopqrstuw~",
  5: "ceilnoprsuv",
  6: "o",
  7: "_aceinorw",
  8: "t"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "related",
  7: "defines",
  8: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Friends",
  7: "Macros",
  8: "Pages"
};

