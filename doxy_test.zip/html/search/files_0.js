var searchData=
[
  ['cpp_5fstring_2eh',['cpp_string.h',['../cpp__string_8h.html',1,'']]]
];
