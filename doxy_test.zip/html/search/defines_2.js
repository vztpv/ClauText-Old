var searchData=
[
  ['col_5fbased',['COL_BASED',['../global_8h.html#a983bca41b29ec473e7c88d2e624fed15',1,'global.h']]]
];
