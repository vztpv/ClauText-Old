var searchData=
[
  ['newarrays_2eh',['newArrays.h',['../new_arrays_8h.html',1,'']]]
];
