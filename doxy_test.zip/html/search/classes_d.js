var searchData=
[
  ['usertype',['UserType',['../classwiz_1_1load__data_1_1_user_type.html',1,'wiz::load_data']]],
  ['utility',['Utility',['../classwiz_1_1load__data_1_1_utility.html',1,'wiz::load_data']]]
];
