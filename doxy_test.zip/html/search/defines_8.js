var searchData=
[
  ['wiz_5fin',['WIZ_IN',['../global_8h.html#a022bb290c83af075db918841470161f0',1,'global.h']]]
];
