var searchData=
[
  ['_5fcrt_5fsecure_5fno_5fwarnings',['_CRT_SECURE_NO_WARNINGS',['../test_010_865_8cpp.html#af08ec37a8c99d747fb60fa15bc28678b',1,'test 0.65.cpp']]]
];
