var searchData=
[
  ['row_5fbased',['ROW_BASED',['../global_8h.html#a47c26b6f949d89a5d2e25163a973e8cb',1,'global.h']]]
];
