var searchData=
[
  ['in',['IN',['../global_8h.html#ac2bbd6d630a06a980d9a92ddb9a49928',1,'global.h']]],
  ['inout',['INOUT',['../global_8h.html#a62766f3ea8784d1db62df989f8f33d2d',1,'global.h']]]
];
