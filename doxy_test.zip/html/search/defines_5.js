var searchData=
[
  ['not',['NOT',['../global_8h.html#ad3e9fe0ec59d2dbb3982ababa042720c',1,'global.h']]]
];
